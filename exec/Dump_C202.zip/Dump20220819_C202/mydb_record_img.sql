-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7c202.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `record_img`
--

DROP TABLE IF EXISTS `record_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record_img` (
  `record_img_id` int NOT NULL AUTO_INCREMENT,
  `record_img_name` varchar(200) DEFAULT NULL,
  `record_img_oriname` varchar(300) DEFAULT NULL,
  `record_img_fileurl` varchar(500) NOT NULL,
  PRIMARY KEY (`record_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record_img`
--

LOCK TABLES `record_img` WRITE;
/*!40000 ALTER TABLE `record_img` DISABLE KEYS */;
INSERT INTO `record_img` VALUES (218,NULL,'107_440_2022-08-19.png','/upload/440_record_107_440_2022-08-19.png'),(219,NULL,'95_440_2022-08-19.png','/upload/440_record_95_440_2022-08-19.png'),(220,NULL,'107_439_2022-08-19.png','/upload/439_record_107_439_2022-08-19.png'),(221,NULL,'107_441_2022-08-19.png','/upload/441_record_107_441_2022-08-19.png'),(222,NULL,'107_439_2022-08-19.png','/upload/439_record_107_439_2022-08-19.png'),(223,NULL,'95_439_2022-08-19.png','/upload/439_record_95_439_2022-08-19.png'),(224,NULL,'107_442_2022-08-19.png','/upload/442_record_107_442_2022-08-19.png'),(225,NULL,'107_442_2022-08-19.png','/upload/442_record_107_442_2022-08-19.png'),(226,NULL,'107_444_2022-08-19.png','/upload/444_record_107_444_2022-08-19.png'),(227,NULL,'107_452_2022-08-19.png','/upload/452_record_107_452_2022-08-19.png'),(229,NULL,'94_452_2022-08-19.png','/upload/452_record_94_452_2022-08-19.png'),(231,NULL,'99_453_2022-08-19.png','/upload/453_record_99_453_2022-08-19.png'),(232,NULL,'94_453_2022-08-19.png','/upload/453_record_94_453_2022-08-19.png'),(233,NULL,'107_454_2022-08-19.png','/upload/454_record_107_454_2022-08-19.png'),(235,NULL,'107_456_2022-08-19.png','/upload/456_record_107_456_2022-08-19.png'),(238,NULL,'95_464_2022-08-19.png','/upload/464_record_95_464_2022-08-19.png'),(239,NULL,'99_464_2022-08-19.png','/upload/464_record_99_464_2022-08-19.png'),(240,NULL,'99_465_2022-08-19.png','/upload/465_record_99_465_2022-08-19.png'),(241,NULL,'95_465_2022-08-19.png','/upload/465_record_95_465_2022-08-19.png');
/*!40000 ALTER TABLE `record_img` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:37:26
