-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7c202.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `meeting_room`
--

DROP TABLE IF EXISTS `meeting_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_room` (
  `meeting_room_id` int NOT NULL AUTO_INCREMENT,
  `meeting_room_name` varchar(50) NOT NULL,
  `meeting_room_secret` tinyint(1) DEFAULT NULL,
  `meeting_room_mode` varchar(50) DEFAULT NULL,
  `meeting_room_type` varchar(50) DEFAULT NULL,
  `meeting_room_link` varchar(500) DEFAULT NULL,
  `meeting_room_open_date` datetime DEFAULT NULL,
  `meeting_room_start_date` datetime DEFAULT NULL,
  `meeting_room_end_date` datetime DEFAULT NULL,
  `meeting_room_password` varchar(50) DEFAULT NULL,
  `meeting_room_reg_dt` datetime DEFAULT NULL,
  `meeting_room_img` varchar(500) DEFAULT NULL,
  `meeting_room_manager` int NOT NULL,
  `meeting_room_status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`meeting_room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=466 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_room`
--

LOCK TABLES `meeting_room` WRITE;
/*!40000 ALTER TABLE `meeting_room` DISABLE KEYS */;
INSERT INTO `meeting_room` VALUES (438,'영상_테스트',0,'STREAMING','HOME','https://www.youtube.com/watch?v=myNjmnvI6x0','2022-08-19 08:47:24',NULL,NULL,'',NULL,NULL,99,'END'),(439,'운동하자!',0,'FREE','BODYWEIGHT','','2022-08-19 08:49:18',NULL,NULL,'',NULL,NULL,107,'END'),(440,'같이 스트레칭 하실 분 괌',0,'FREE','STRETCHING','','2022-08-19 08:53:04',NULL,NULL,'',NULL,NULL,107,'END'),(441,'자유_연습',0,'FREE','HOME','','2022-08-19 08:58:03',NULL,NULL,'',NULL,NULL,99,'END'),(442,'열운^^',0,'FREE','HOME','','2022-08-19 09:09:44',NULL,NULL,'',NULL,NULL,107,'END'),(444,'Yo, ga',0,'FREE','YOGA','','2022-08-19 09:18:50',NULL,NULL,'',NULL,NULL,107,'END'),(447,'하나',0,'FREE','HEALTH','','2022-08-19 09:24:25',NULL,NULL,'',NULL,NULL,94,'END'),(448,'시간테스트123',0,'FREE','PILATES','','2022-08-19 09:24:40',NULL,NULL,'',NULL,NULL,99,'END'),(451,'오늘운동중',1,'FREE','HEALTH','','2022-08-19 09:45:46',NULL,NULL,'4325',NULL,NULL,98,'END'),(452,'40분 홈트 달리실분?',0,'STREAMING','HOME','https://www.youtube.com/watch?v=myNjmnvI6x0','2022-08-19 10:03:28',NULL,NULL,'',NULL,NULL,99,'END'),(453,'홈트 같이해ㅔ요~',0,'STREAMING','HOME','https://www.youtube.com/watch?v=myNjmnvI6x0','2022-08-19 10:12:31',NULL,NULL,'',NULL,NULL,99,'END'),(454,'홈트 원츄~',0,'STREAMING','HOME','https://www.youtube.com/watch?v=myNjmnvI6x0','2022-08-19 10:15:03',NULL,NULL,'',NULL,NULL,99,'END'),(455,'발표테스트!!!!@!@',0,'FREE','HEALTH','','2022-08-19 10:17:37',NULL,NULL,'',NULL,NULL,93,'END'),(456,'다들 들어와 프리덤!하자',0,'FREE','HEALTH','','2022-08-19 10:19:31',NULL,NULL,'',NULL,NULL,93,'END'),(457,'한판 제대로 붙어보자!',0,'GAME','GAME','','2022-08-19 10:21:35',NULL,NULL,'',NULL,NULL,99,'END'),(458,'내가 더 잘함',0,'GAME','GAME','','2022-08-19 10:31:45',NULL,NULL,'',NULL,NULL,99,'END'),(459,'내가 더 잘함',0,'GAME','GAME','','2022-08-19 10:32:35',NULL,NULL,'',NULL,NULL,109,'END'),(460,'내가 더 잘함',0,'GAME','GAME','','2022-08-19 10:33:26',NULL,NULL,'',NULL,NULL,99,'END'),(461,'경쟁하자!',0,'GAME','GAME','','2022-08-19 10:41:10',NULL,NULL,'',NULL,NULL,109,'END'),(462,'나이길수있는사람',0,'FREE','STRETCHING','','2022-08-19 10:48:54',NULL,NULL,'',NULL,NULL,98,'END'),(463,'코딩하다가 한판 ㄱ?',0,'GAME','GAME','','2022-08-19 11:00:49',NULL,NULL,'',NULL,NULL,98,'END'),(464,'가벼운 운동하실 분',0,'FREE','STRETCHING','','2022-08-19 11:26:28',NULL,NULL,'',NULL,NULL,95,'END'),(465,'운동운동운동',0,'FREE','HEALTH','','2022-08-19 11:27:56',NULL,NULL,'',NULL,NULL,95,'END');
/*!40000 ALTER TABLE `meeting_room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:37:26
