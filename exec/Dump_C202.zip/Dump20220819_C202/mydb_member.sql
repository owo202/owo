-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7c202.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` int NOT NULL AUTO_INCREMENT,
  `member_email` varchar(30) NOT NULL,
  `member_pw` varchar(100) NOT NULL,
  `member_nick` varchar(30) DEFAULT NULL,
  `member_gender` varchar(6) DEFAULT NULL,
  `member_age` int DEFAULT '0',
  `member_height` double DEFAULT '0',
  `member_weight` double DEFAULT '0',
  `member_activity_num` int DEFAULT '0',
  `member_activity_hour` int DEFAULT '0',
  `member_point` int DEFAULT '0',
  `member_secret` tinyint(1) DEFAULT '0',
  `member_exp` int DEFAULT '0',
  `member_joindate` datetime DEFAULT NULL,
  `member_slogan` varchar(50) DEFAULT NULL,
  `member_enable` tinyint(1) DEFAULT NULL,
  `profile_img_id` int DEFAULT NULL,
  `profile_id` int DEFAULT NULL,
  `member_refresh_token` varchar(500) DEFAULT NULL,
  `member_activity_level` int DEFAULT '0',
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `member_email_UNIQUE` (`member_email`),
  KEY `member_profile_img_id_idx` (`profile_img_id`),
  CONSTRAINT `member_profile_img_id` FOREIGN KEY (`profile_img_id`) REFERENCES `profile_img` (`profile_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (93,'sky99124@naver.com','1234','kaydenna','MALE',31,184,78,0,0,80,0,0,'2022-08-18 11:22:47','Just Do IT!!!!! 해내자!',1,104,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJza3k5OTEyNEBuYXZlci5jb20iLCJyb2xlcyI6WyJST0xFX1VTRVIiXSwiaWF0IjoxNjYwODc2NDc0LCJleHAiOjE2NjE0ODEyNzR9.1VpdoQpN4Al3XPrTb9sNsMlzZn4VqVN5SYMAq19_INA',2),(94,'baekhannah@naver.com','1234','한나','FEMALE',27,156,43,0,0,30,0,0,'2022-08-18 11:23:20','11월 바프까지 화이팅!',1,NULL,NULL,'invalidate',4),(95,'lgeun123@naver.com','1234','으니','FEMALE',25,161,40,0,0,0,0,0,'2022-08-18 11:33:38',NULL,1,107,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJsZ2V1bjEyM0BuYXZlci5jb20iLCJyb2xlcyI6WyJST0xFX1VTRVIiXSwiaWF0IjoxNjYwODc1NjY2LCJleHAiOjE2NjE0ODA0NjZ9.aNOM2RA1SkurS6TV8na7LdGURGmF_UoZJZEe9eBxTns',1),(96,'kaydenna92@gmail.com','social','kayden na',NULL,0,0,0,0,0,0,0,0,'2022-08-18 11:37:37',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJrYXlkZW5uYTkyQGdtYWlsLmNvbSIsInJvbGVzIjpbIlJPTEVfVVNFUiJdLCJpYXQiOjE2NjA4NzQzMDMsImV4cCI6MTY2MTQ3OTEwM30.bT5No6G2vqfhKGyttxq4pHGKyMHr6Q75X5xMhA7a4S8',0),(97,'kaden921205@gmail.com','1234','나장엽','MALE',31,184,86,0,0,0,0,0,'2022-08-18 11:40:09','Just Do IT!!!!!',1,NULL,NULL,'invalidate',3),(98,'dew4325@naver.com','1234','다슬기','FEMALE',20,180,30,0,0,25,0,0,'2022-08-18 11:47:22',NULL,1,106,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJkZXc0MzI1QG5hdmVyLmNvbSIsInJvbGVzIjpbIlJPTEVfVVNFUiJdLCJpYXQiOjE2NjA4NzQzNDQsImV4cCI6MTY2MTQ3OTE0NH0.ZR5z6hr5MNdBz5A0azOowO36E6r_OrU26lMp7kE0iug',1),(99,'nak3652@naver.com','1234','주노잼','MALE',20,172,70,0,0,135,0,0,'2022-08-18 12:02:41','할 수 있다!!!!!',1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJuYWszNjUyQG5hdmVyLmNvbSIsInJvbGVzIjpbIlJPTEVfVVNFUiJdLCJpYXQiOjE2NjA4NzU4ODMsImV4cCI6MTY2MTQ4MDY4M30.Bt0Ut8XYalssgbGTl3oJH3bbmtbP1AgN7QBw2_QkTC0',3),(100,'sjhyun1006@naver.com','social','소정현',NULL,0,0,0,0,0,5,0,0,'2022-08-18 13:31:15',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzamh5dW4xMDA2QG5hdmVyLmNvbSIsInJvbGVzIjpbIlJPTEVfVVNFUiJdLCJpYXQiOjE2NjA3OTgxNzksImV4cCI6MTY2MTQwMjk3OX0.2FiD3EG9ThUTTU16VehAruTCHMNsxVFJhoCTvcOASc4',0),(101,'dlwoals0850@gmail.com','social','[광주_2반_이재민]',NULL,0,0,0,0,0,0,0,0,'2022-08-18 13:33:37',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJkbHdvYWxzMDg1MEBnbWFpbC5jb20iLCJyb2xlcyI6WyJST0xFX1VTRVIiXSwiaWF0IjoxNjYwNzk3MjE3LCJleHAiOjE2NjE0MDIwMTd9.RmWAQKzWzQ-qpsztieZ8cOMz4WB6Ufif5WlSiS2tH14',0),(102,'mayakpari@gmail.com','social','양승호',NULL,0,0,0,0,0,0,0,0,'2022-08-18 13:34:08',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJtYXlha3BhcmlAZ21haWwuY29tIiwicm9sZXMiOlsiUk9MRV9VU0VSIl0sImlhdCI6MTY2MDc5NzI0OCwiZXhwIjoxNjYxNDAyMDQ4fQ.wZqC1J7g712p3Q6oeP4df1B6FNwSQ9Q57EdOyw0HcVI',0),(103,'test@test.com','test',NULL,NULL,0,0,0,0,0,0,0,0,'2022-08-18 13:56:30',NULL,0,NULL,NULL,NULL,0),(104,'uk7880@naver.com','social','서정욱','MALE',35,189,87,0,0,0,0,0,'2022-08-18 13:56:52',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1azc4ODBAbmF2ZXIuY29tIiwicm9sZXMiOlsiUk9MRV9VU0VSIl0sImlhdCI6MTY2MDc5OTAxNSwiZXhwIjoxNjYxNDAzODE1fQ.c8wM-UkW5rG4R3YUk_azW0bmHvwujzx2r4Lf6iQg0Tc',3),(105,'dltmdgml456654@gmail.com','social','엘렌이',NULL,0,0,0,0,0,10,0,0,'2022-08-18 15:43:21',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJkbHRtZGdtbDQ1NjY1NEBnbWFpbC5jb20iLCJyb2xlcyI6WyJST0xFX1VTRVIiXSwiaWF0IjoxNjYwODYwNjcxLCJleHAiOjE2NjE0NjU0NzF9.vf3rjjmZewdd_gqvdb592coen_dvGGLnfjpvePOzicE',0),(106,'euni23962@gmail.com','social','이지은',NULL,0,0,0,0,0,0,0,0,'2022-08-18 19:22:22',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJldW5pMjM5NjJAZ21haWwuY29tIiwicm9sZXMiOlsiUk9MRV9VU0VSIl0sImlhdCI6MTY2MDg0MjMzMywiZXhwIjoxNjYxNDQ3MTMzfQ.LW4U4cb_-ZFFkmTlPui8kVDGcuJYMw_wt-kwyXA1Jgs',0),(107,'hithere1012@naver.com','social','미라클운동','FEMALE',25,190,60,0,0,15,0,0,'2022-08-19 07:01:39','Just Do it!',1,105,NULL,'invalidate',5),(108,'lovelyhannayam@nate.com','social','백한나',NULL,0,0,0,0,0,0,0,0,'2022-08-19 08:09:34',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJsb3ZlbHloYW5uYXlhbUBuYXRlLmNvbSIsInJvbGVzIjpbIlJPTEVfVVNFUiJdLCJpYXQiOjE2NjA4NjQxNzQsImV4cCI6MTY2MTQ2ODk3NH0.9D8QpwdgahiPcX9JLjkTLwjrAWn4iYvkR45PybHqV6E',0),(109,'junojam0622@gmail.com','social','이준호',NULL,0,0,0,0,0,0,0,0,'2022-08-19 08:23:33',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqdW5vamFtMDYyMkBnbWFpbC5jb20iLCJyb2xlcyI6WyJST0xFX1VTRVIiXSwiaWF0IjoxNjYwODczMjU5LCJleHAiOjE2NjE0NzgwNTl9.iJ7JFAzlo7V2SeZX6RMpMseFWol66NQibaL1mTw7zYw',0),(110,'dew4325@icloud.com','social','안다슬',NULL,0,0,0,0,0,10,0,0,'2022-08-19 10:34:02',NULL,1,NULL,NULL,'invalidate',0),(111,'admin@owo.com','bestowo','관리자',NULL,0,0,0,0,0,0,0,0,'2022-08-19 00:00:00',NULL,1,NULL,NULL,'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbkBvd28uY29tIiwicm9sZXMiOltdLCJpYXQiOjE2NjA4NzUyNjgsImV4cCI6MTY2MTQ4MDA2OH0.5n5990NGFkrrOVbY-oAuSHG9g61vipQH56sEJiKuxl4',0);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:37:27
