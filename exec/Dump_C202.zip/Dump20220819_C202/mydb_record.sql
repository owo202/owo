-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7c202.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `record`
--

DROP TABLE IF EXISTS `record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record` (
  `record_id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `record_time` int DEFAULT NULL,
  `record_memo` varchar(1000) DEFAULT NULL,
  `meeting_room_id` int NOT NULL,
  `record_secret` tinyint(1) DEFAULT NULL,
  `record_datetime` datetime(6) DEFAULT NULL,
  `record_img_id` int DEFAULT NULL,
  `record_exercise` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`record_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `meeting_room_id_idx` (`meeting_room_id`),
  KEY `record_img_id_idx` (`record_img_id`),
  CONSTRAINT `record_img_id` FOREIGN KEY (`record_img_id`) REFERENCES `record_img` (`record_img_id`),
  CONSTRAINT `record_meeting_room_id` FOREIGN KEY (`meeting_room_id`) REFERENCES `meeting_room` (`meeting_room_id`),
  CONSTRAINT `record_member_id` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record`
--

LOCK TABLES `record` WRITE;
/*!40000 ALTER TABLE `record` DISABLE KEYS */;
INSERT INTO `record` VALUES (215,107,49,'아침에 오운완하니 너무 상쾌하다',440,0,'2022-06-18 00:00:00.000000',218,'STRETCHING'),(216,95,208,'운동을 하니 건강해지는 기분',440,0,'2022-07-03 00:00:00.000000',219,'STRETCHING'),(217,107,19,'팔벌려 운동하기!',439,0,'2022-07-10 00:00:00.000000',220,'BODYWEIGHT'),(218,107,117,'어우 몸이 가볍다',441,0,'2022-07-19 00:00:00.000000',221,'HOME'),(219,107,22,'시원시원~ 오늘도 오운완!',439,0,'2022-08-02 00:00:00.000000',222,'BODYWEIGHT'),(220,95,117,'오운완~!',439,0,'2022-08-09 00:00:00.000000',223,'BODYWEIGHT'),(221,107,91,'상쾌상쾌 상쾌환~',442,0,'2022-08-10 00:00:00.000000',224,'HOME'),(222,107,77,'뿌듯뿌듯 복근이 떙긴다',442,0,'2022-08-16 00:00:00.000000',225,'HOME'),(223,107,29,'hey, yo. ga.',444,0,'2022-08-18 00:00:00.000000',226,'YOGA'),(224,107,231,'ㅎㅎ',452,0,'2022-08-18 00:00:00.000000',227,'HOME'),(226,94,248,'잠보단 역시 운동이지',452,0,'2022-08-18 00:00:00.000000',229,'HOME'),(228,99,77,'후..',453,0,'2022-08-18 00:00:00.000000',231,'HOME'),(229,94,71,'재밌다~~ 잘 가르쳐주신다 유튜브 보면서 하니까 좋네',453,0,'2022-08-19 00:00:00.000000',232,'HOME'),(230,107,60,'운동 최고',454,0,'2022-08-18 00:00:00.000000',233,'HOME'),(232,107,163,'메모',456,0,'2022-08-19 00:00:00.000000',235,'HEALTH'),(235,95,23,'운동운동',464,0,'2022-08-19 00:00:00.000000',238,'STRETCHING'),(236,99,27,'힘드네..',464,0,'2022-08-19 00:00:00.000000',239,'STRETCHING'),(237,99,17,'후..',465,0,'2022-08-19 00:00:00.000000',240,'HEALTH'),(238,95,18,'나는야 몸짱',465,0,'2022-08-19 00:00:00.000000',241,'HEALTH');
/*!40000 ALTER TABLE `record` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:37:25
